﻿
# temp path
tempdata_path='/home/csexam/patest/Lo-runner-master/demo/tmpdata'

# temp file name
temp_file_name='tmp.out'

# test data
standard_testdata_path='/home/csexam/patest/Lo-runner-master/demo/testdata'
special_testdata_path='/home/csexam/patest/Lo-runner-master/demo/special'

# source path
source_path='/home/csexam/patest/Lo-runner-master/demo/srcdata'

# gcc and g++ executable file name
exec_name='main' 

# java file name
java_file_name='Main.java'
java_file_name_no_ext='Main'

# gcc file name
gcc_file_name='main.c'

# g++ file name
gpp_file_name='main.cpp'

# python file name
python_file_name='main.py'
python_file_name_no_ext='main'


