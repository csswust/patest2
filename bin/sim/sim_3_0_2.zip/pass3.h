/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: pass3.h,v 1.4 2017-12-03 09:55:23 dick Exp $
*/

/*	Print the contents of runs */
extern void Print_Runs(void);
